/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//funciones de validacion de Mail, CURP y RFC
function validPassword() {

    var password = document.getElementById("input_form:password").value;
    var confirm = document.getElementById("input_form:confirm").value;
    if (password === confirm){
        $("#confirmmsg").css('display', 'none');
        return true;
    } else {
        $("#confirmmsg").css('display', 'inline');
        $("#confirmmsg").html("Contraseñas no coinciden");
        $("#confirmmsg").css('color', 'red');
        return false;
    }
}

function validAnularPassword() {

    var password = document.getElementById("input_form:password2").value;
    var confirm = document.getElementById("input_form:confirm2").value;
    if (password === confirm){
        $("#confirmanumsg").css('display', 'none');
        return true;
    } else {
        $("#confirmanumsg").css('display', 'inline');
        $("#confirmanumsg").html("Contraseñas no coinciden");
        $("#confirmanumsg").css('color', 'red');
        return false;
    }
}
function validEmail() {

    var email = document.getElementById("input_form:email").value;
    var pattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (pattern.test(email)) {
        $("#emailmsg").css('display', 'none');
        return true;
    } else {
        $("#emailmsg").css('display', 'inline');
        $("#emailmsg").html("Formato de email incorrecto");
        $("#emailmsg").css('color', 'red');
        return false;
    }
}
function validCurp() {
    var curp = document.getElementById("input_form:curp").value;
    var pattern = /^[A-Z]{1}[AEIOU]{1}[A-Z]{2}[0-9]{2}(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])[HM]{1}(AS|BC|BS|CC|CS|CH|CL|CM|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS|NE)[B-DF-HJ-NP-TV-Z]{3}[0-9A-Z]{1}[0-9]{1}$/;
    if (pattern.test(curp)) {
        $("#curp").css('display', 'none');
        return true;
    } else {
        $("#curp").css('display', 'inline');
        $("#curp").html("Formato de CURP incorrecto");
        $("#curp").css('color', 'red');
        return false;
    }
}
function validRfc() {
    var rfc = document.getElementById("input_form:rfc").value;
    var pattern = /^([A-ZÑ\x26]{3,4}([0-9]{2})(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])[A-Z|\d]{3})$/;
    if (pattern.test(rfc)) {
        $("#rfcmsg").css('display', 'none');
        return true;
    } else {
        $("#rfcmsg").css('display', 'inline');
        $("#rfcmsg").html("Formato de RFC incorrecto");
        $("#rfcmsg").css('color', 'red');
        return false;
    }
}

function validarTelefono() {
    var telnumber = document.getElementById("input_form:telNumber").value;
    if (telnumber.length == 10) {
        $("#telmsg").css('display', 'none');
        return true;
    } else {
        $("#telmsg").css('display', 'inline');
        $("#telmsg").html("El número telefónico es incorrecto");
        $("#telmsg").css('color', 'red');
        return false;
    }

}

function DateLong(fecha)
{
    var fecha2 = fecha.toLowerCase();
    fecha2 = fecha2.replace("enero","january");
    fecha2 = fecha2.replace("febrero","february");
    fecha2 = fecha2.replace("marzo","march");
    fecha2 = fecha2.replace("abril","april");
    fecha2 = fecha2.replace("mayo","may");
    fecha2 = fecha2.replace("junio","june");
    fecha2 = fecha2.replace("julio","july");
    fecha2 = fecha2.replace("agosto","august");
    fecha2 = fecha2.replace("septiembre","september");
    fecha2 = fecha2.replace("octubre","october");
    fecha2 = fecha2.replace("noviembre","november");
    fecha2 = fecha2.replace("diciembre","december");
    
    return Date.parse(fecha2);
    
}